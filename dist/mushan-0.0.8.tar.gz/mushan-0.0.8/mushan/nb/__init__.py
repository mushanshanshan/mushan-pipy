def test():
    print("hello")